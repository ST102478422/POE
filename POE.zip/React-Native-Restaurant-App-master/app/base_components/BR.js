import styled from 'styled-components';

const BR = styled.View`
  height: ${props => (props.size ? props.size : 20)}
`;


export default BR;
