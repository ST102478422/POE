import React, { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';

const App = () => {
  const menu = [
    { id: '1', name: 'Spring Rolls', course: 'Starters' },
    { id: '2', name: 'Caesar Salad', course: 'Starters' },
    { id: '3', name: 'Grilled Chicken', course: 'Mains' },
    { id: '4', name: 'Steak', course: 'Mains' },
    { id: '5', name: 'Chocolate Cake', course: 'Desserts' },
    { id: '6', name: 'Ice Cream', course: 'Desserts' },
  ];

  const [selectedCourse, setSelectedCourse] = useState('All');

  const courses = ['All', 'Starters', 'Mains', 'Desserts'];

  const filteredMenu =
    selectedCourse === 'All'
      ? menu
      : menu.filter((item) => item.course === selectedCourse);

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Menu</Text>
      <View style={styles.filterContainer}>
        {courses.map((course) => (
          <TouchableOpacity
            key={course}
            style={[
              styles.filterButton,
              selectedCourse === course && styles.activeButton,
            ]}
            onPress={() => setSelectedCourse(course)}
          >
            <Text
              style={[
                styles.filterText,
                selectedCourse === course && styles.activeText,
              ]}
            >
              {course}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
      <FlatList
        data={filteredMenu}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.menuItem}>
            <Text style={styles.menuText}>{item.name}</Text>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f8f8f8',
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  filterContainer: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  filterButton: {
    padding: 10,
    backgroundColor: '#ddd',
    borderRadius: 5,
    marginRight: 10,
  },
  activeButton: {
    backgroundColor: '#4caf50',
  },
  filterText: {
    fontSize: 16,
  },
  activeText: {
    color: '#fff',
  },
  menuItem: {
    padding: 15,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  menuText: {
    fontSize: 18,
  },
});

export default App;
