const ImageSource = [
  '../../assets/images/chinese.png',
  '../../assets/images/south-indian.png',
  '../../assets/images/beverages.png',
  '../../assets/images/north-indian.png',
  '../../assets/images/biryani.png',
];

export default ImageSource;

